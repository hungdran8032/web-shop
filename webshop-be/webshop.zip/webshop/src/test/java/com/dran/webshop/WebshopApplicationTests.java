package com.dran.webshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebshopApplicationTests {

	@Test
	void contextLoads() {
	}

}
